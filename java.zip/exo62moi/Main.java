import org.apache.commons.math3.complex.Complex;
/**
 * Décrivez votre classe Main ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Main
{
    public static void main()
    {
        Complex c1 = new Complex(5);
        System.out.println(c1.abs());
    }
}
