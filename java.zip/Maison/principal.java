
/**
 * Décrivez votre classe principal ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class principal
{
    public static void main() {
        Fenetre f = new Fenetre();
    }
}
